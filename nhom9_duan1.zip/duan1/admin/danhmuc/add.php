<h1>Thêm danh mục sản phẩm</h1>

        <div class="content-box">
        <form id="product-form" method="POST" action="index.php?act=adddm">    
             <div class="wrap-field">
             <label>Mã danh mục</label>
                <input type="text" name="maloai" disabled>
                <div class="clear-both"></div>
            </div>
            <div class="wrap-field">
            <label>Tên danh mục</label>
                <input type="text" name="tenloai">
                <div class="clear-both"></div>
            </div>
           
             <input type="submit" name="themmoi" value="Thêm danh mục">
           
        </form>
