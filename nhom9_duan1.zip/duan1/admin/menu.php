
    <input type="checkbox" id="nav-toggle">
    <div class="sidebar">
        <div class="sidebar-brand">
            <h1><span class=""> Y-SHOP</span></h1>
        </div>
        <div class="sidebar-menu">
            <ul>
                <li>
                    <a href="index.php?act=dashboard"><span class="las la-igloo"></span><span>DashBoard</span></a>
                </li>
                <li>
                    <a href="index.php?act=listdm"><span class="las la-list"></span><span>Thương hiệu</span></a>
                </li>
                <li>
                    <a href="index.php?act=listsp"><span class="las la-shopping-bag"></span><span>Sản phẩm</span></a>
                </li>
                <li>
                    <a href="index.php?act=dskh"><span class="las la-users"></span><span>Người dùng</span></a>
                </li>
                <li>
                    <a href="index.php?act=dsbl"><span class="las la-comment"></span><span>Bình luận</span></a>
                </li>
                <li>
                    <a href="index.php?act=thongke"><span class="las la-clipboard-list"></span><span>Thống kê</span></a>
                </li>
                <li>
                    <a href="index.php?act=listbill"><span class="las la-shopping-cart"></span><span>Đơn hàng</span></a>
                </li>
            </ul>
        </div>
    </div>